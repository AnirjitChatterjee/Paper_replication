getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/main/4a")

data = read.table(file = "immune_coordinates_gc_compiled", header = F)
jpeg("4a_scatter.jpeg",width=20,height=11.5,units="in",res=300)
Rpt_ln = (data$V6 - data$V5)
Gene_ln = data$V10
plot(Rpt_ln,Gene_ln,pch=ifelse((Gene_ln<10000 & (Rpt_ln)<750),13,19),cex=ifelse((Gene_ln<10000 & (Rpt_ln)<750),1,1.5),col=ifelse((Gene_ln<10000 & (Rpt_ln)<750),"darkseagreen2","bisque3"),main="Repeat length change with gene length change",xlab="Length of Repeat (nucleotides)",ylab="Length of Gene (nucleotides)",cex.axis=1,cex.lab=1.2)
new_data = data[Gene_ln>10000 | Rpt_ln>750,]
unique(new_data$V2)
##This gives 11 unique genes

hrg = data[data$V2 == "HRG", ]
points(hrg$V6-hrg$V5, hrg$V10, col="cyan", cex=1, pch=19)

km2ta = data[data$V2=="KMT2A",]
km2ta_n = km2ta[km2ta$V4=="S" | km2ta$V4=="AGS", ] 
#This gene has many non-orthologous repeats in different clades, we have subsetted only the orthologous repeats
points(km2ta_n$V6 - km2ta_n$V5, km2ta_n$V10, col="darkblue", cex=1, pch=19)

lrp1 = data[data$V2 == "LRP1", ]
##LRP1 has two distinct LRRs, one at beginning and one at end of the gene. So, we have to do a coordinate based search and use two different pch of same color to represent distinct repeats of same gene
lrp1_1 = lrp1[lrp1$V6<500, ]
points(lrp1_1$V6 - lrp1_1$V5, lrp1_1$V10, col="lightpink", cex=1, pch=19)
lrp1_2 = lrp1[lrp1$V6>500, ]
points(lrp1_2$V6 - lrp1_2$V5, lrp1_2$V10, col="lightpink", cex=1, pch=19)

lyst = data[data$V2 == "LYST",]
##LYST also has two repeats, but the second repeat is only in one clade. So we use only the first repeat which has orthologs across multiple clades
lyst_1 = lyst[lyst$V5<300, ]
points(lyst_1$V6 - lyst_1$V5, lyst_1$V10, col="brown", cex=1, pch=19)

##PKHD1L1 has some repeat in initial in Artiodactyla only, we removed it
pkhdl1 = data[data$V2 == "PKHD1L1", ]
pkhdl1_1 = pkhdl1[pkhdl1$V5>12000, ]
points(pkhdl1_1$V6 - pkhdl1_1$V5, pkhdl1_1$V10, col="seagreen", cex=1, pch=19)

#####PRG4 has one repeat inside another repeat, and one is far away from others
prg4 = data[data$V2 == "PRG4", ]
prg4_1 = prg4[prg4$V7<600,]
points(prg4_1$V6 - prg4_1$V5, prg4_1$V10, col="orange", cex=1, pch=19)
prg4_2 = prg4[prg4$V5>500,]
points(prg4_2$V6 - prg4_2$V5, prg4_2$V10, col="orange", cex=1, pch=19)

rnf213 = data[data$V2 == "RNF213", ]
###RNF213 has clade specific repeats but we are selecting the repeats which are orthologous across different clades
rnf213_1 = rnf213[rnf213$V4 == "K" | rnf213$V4 == "KR", ]
points(rnf213_1$V6 - rnf213_1$V5, rnf213_1$V10, col="gold4", cex=1, pch=19)

legend(x=2500,y=15000, legend = c("HRG","KMT2A","LRP1","LYST","PKHD1L1","PRG4","RNF213","Outliers"), col=c("cyan" ,"darkblue","lightpink","brown","seagreen","orange","gold4","bisque3"), pt.cex = 3, cex = 1.5,  horiz = F, box.lwd = 0 ,box.col = "white", bg = "white", pch=19, title="Genes", text.font=c(rep(3,7),1))
dev.off()