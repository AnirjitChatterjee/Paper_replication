getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Downloads")

dat = read.csv(file = "1b_table.csv", header = TRUE)
dat
head(dat)


Adapt = dat$Adaptive.immune.response.genes
Innate = dat$Innate.immune.response.genes
Repeats = dat$Immune.system.process.genes.with.repeats

Adapt_c = Adapt[Adapt != ""]
Innate_c = Innate[Innate != ""]
Repeats_c = Repeats[Repeats != ""]

A = length(Adapt_c)
I = length(Innate_c)
R = length(Repeats_c)

A_I = length(intersect(Adapt_c,Innate_c))
I_R = length(intersect(Innate_c,Repeats_c))
A_R = length(intersect(Adapt_c,Repeats_c))

A_I_R = length(intersect(Adapt_c, intersect(Innate_c,Repeats_c)))

install.packages("VennDiagram")
library("VennDiagram")
jpeg("Venn_1b.jpeg",width=15,height=15,units="in",res=300)
grid.newpage()
draw.triple.venn(area1=A,area2=I,area3=R,n12=A_I,n23=I_R,n13=A_R,n123=A_I_R,cross.area=overlap,category=c("Adaptive immune response genes","Innate immune response genes","Immune system process genes having repeats"),fill=c("blue","yellow","pink"),lty="blank",cex=2,cat.cex=1.5,cat.pos=c(-30,30,-180))
dev.off()