setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/main/2b")

d=read.csv(file = "2b.csv", header = T)
v1 = d$Clade
v2 = d$GC_percent
v3 = d$Repeat_status
data = data.frame(Clade = v1, Status = v3, GC_percent = v2)

jpeg("2b.jpeg",width=28,height=18,units="in",res=300)
par(mar=c(5,4,4,1))
myplot <- boxplot(GC_percent ~ Status*Clade, data = data, boxwex = 0.4, ann = F, col = c("skyblue" , "pink"), border=c("darkblue", "red"), cex.axis = 1.25, xaxt = "n")
title(main="GC% variation in proteins with repeats and proteins without repeats" ,cex.main=2)
title(ylab="GC%", line = 2, cex.lab=2)        
title(xlab="Clades", line = 2, cex.lab=2)
axis(1, at = seq(1.5 , 24 , 2), labels = unique(v1), tick=FALSE, cex.axis=1)

for(i in seq(0.5 , 26 , 2)){ 
  abline(v=i,lty=4, col="black",lwd=1.5)
}

legend(x=21, y=35, legend = c("Proteins with repeats", "Proteins without repeats"), col=c("skyblue" , "pink"),pch = 15, pt.cex = 4, cex = 2, inset = c(0.1, 0.1), box.lwd = 0, box.col = "white",bg = "white")

xpos=1
for(clade in unique(v1)){
  r = data[data$Clade==clade & data$Status=="With_repeats",]
  n = data[data$Clade==clade & data$Status=="Without_repeats",]
  mxm = max(quantile(r$GC_percent,probs=0.75),quantile(n$GC_percent,probs=0.75))
  y_up = mxm+4
  w = wilcox.test(r$GC_percent,n$GC_percent,alternative="greater")
  p_value = signif(w$p.value,digits=3)
  text(xpos+0.5,y_up+0.6,labels=p_value,cex=1.2)
  r_avg = round(mean(r$GC_percent),digits=2)
  n_avg = round(mean(n$GC_percent),digits=2)
  mnm = min(quantile(r$GC_percent,probs=0.25),quantile(n$GC_percent,probs=0.25))
  y_down = mnm-2
  text(xpos,y_down,bquote(bar("x") == .(r_avg)),cex=0.9)
  text(xpos+1,y_down,bquote(bar("x") == .(n_avg)),cex=0.9)
  text(xpos,y_down-3,bquote("n" == .(dim(r)[1])),cex=0.9)
  text(xpos+1,y_down-3,bquote("n" == .(dim(n)[1])),cex=0.9)
  xpos=xpos+2
}
dev.off()