getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/4b")

library(ape)
library(stringr)
library(TreeTools)
library(tidytree)

data = read.csv("4b_table.csv", header = T)
tab = read.tree("hrg.nwk")
clade = tolower(unique(data$Clade))
clade_name = str_to_title(clade)
gene = toupper(unique(data$Gene))
r = unique(data$Repeat)

rpt = data.frame(aa = r, c("red", "blue"))
colnames(rpt) = c("residue","color")

final = data
t <- keep.tip(tab,unique(final$Organism))
pt = Preorder(t)
heightparam = max(((length(t$tip.label))*0.435) + 1.70, 14)
species = as.data.frame(t$tip.label)
colnames(species) = c("spnames")
final$rpt_ln = (final$End_u - final$Start_u ) + 1
jpeg(paste('4b.jpeg',sep=''),width=28,height=heightparam,units="in",res=300)
par(mai = c(0.4,0,0.4,0), oma = c(0,0.4,0,0.2), xpd = T)
layout(matrix(c(1,2,2,2), nrow = 1, byrow = T))
###Firstly, plotting the species tree for the gene
phylolim = max(((length(t$tip.label))/5) + 6, 14)
plot.phylo(t, use.edge.length = F, node.depth = 2, label.offset = 0.1, x.lim = phylolim, cex = 1.5)
ymax = 2*length(t$tip.label)
plot(1, type="n", xlab="", ylab="", xlim=c(0, max(final$Length_a)), ylim=c(0, ymax-2), axes=F)
###Plotting the recatangular boxes on the right side of the plot
for(j in seq(0,length(t$tip.label)-1,1)){
  y1=(2*j)-0.5
  y2=(2*j)+0.5
  rect(0,y1,max(final$Length_a),y2, col = "lightgrey")}
###Plotting the repeats at their specific coordinates
for (z in 1:dim(final)[1]){
  b1 = final[z,]
  spnaam=b1[1,"Organism"]
  ###get the number at which the species is written
  j = which(species$spnames==spnaam)
  x1 = b1$Start_a
  x2 = b1$Start_a + b1$rpt_ln
  s = as.character(b1$Repeat)
  #print(s)
  y1=((2*j)-0.5)-2
  y2=((2*j)+0.5)-2
  if(s == "GHP"){
    rect(x1,y1,x2,y2, brder="transparent", col=c("red"), lty="dashed", density=100, angle=45*i)}
  if(s == "HP"){
    rect(x1,y1,x2,y2, brder="transparent", col=c("blue"), lty="dashed", density=100, angle=45*i)}
  rplabel=paste(b1$Repeat,' (',b1$rpt_ln,') ',sep='')
  text((x1+x2)/2,y2+0.3,labels=rplabel)
}

legend("bottomright", legend = c(rpt$residue), col = c(rpt$color) , horiz = T, fill = rpt$color, inset = c(0.042,-0.01), bty="n", cex=2)
title = substitute('Repeat length distribution of'~italic(gene)~'gene across different species in'~clade~'clade',list(gene=gene,clade=clade_name))
mtext(title ,side=3,cex=2,adj=0.5,outer=T,line=-4)
dev.off()
