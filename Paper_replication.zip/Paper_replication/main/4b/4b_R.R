getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/main/4b")

library(ape)
library(stringr)
library(TreeTools)
library(tidytree)

data = read.csv("4b_table.csv", header = T)
tab = read.tree("hrg.nwk")
r = unique(data$Repeat)

rpt = data.frame(aa = r, c("red","blue"))
colnames(rpt) = c("residue","color")

t <- keep.tip(tab,unique(data$Organism))
orgs = as.data.frame(t$tip.label)
colnames(orgs) = c("org_names")
data$rpt_ln = (data$End_u - data$Start_u ) + 1

jpeg(paste('4b.jpeg',sep=''),width=28,height=14,units="in",res=300)
par(mai = c(0.4,0,0.4,0), oma = c(0,0.4,0,0.2), xpd = T)
layout(matrix(c(1,2,2,2), nrow = 1, byrow = T))

###Firstly, plotting the orgs tree for the gene
plot.phylo(t, use.edge.length = F, node.depth = 2, label.offset = 0.1, x.lim = 20, cex = 1.5)
ymax = 2*length(t$tip.label)
xlen = max(data$Length_a)
plot(1, type="n", xlab="", ylab="", xlim=c(0, xlen), ylim=c(0, ymax-2), axes=F)

###Plotting the recatangular boxes on the right side of the plot
n = length(t$tip.label)-1
for(j in seq(0,n,1)){
  y1=(2*j)-0.5
  y2=(2*j)+0.5
  rect(0,y1,xlen,y2, col = "lightgrey")}

###Plotting the repeats at their specific coordinates
for (z in 1:dim(data)[1]){
  b1 = data[z,]
  spnaam=b1[1,"Organism"]
  ###get the number at which the orgs is written
  j = which(orgs$org_names==spnaam)
  x1 = b1$Start_a
  x2 = b1$Start_a + b1$rpt_ln
  rep = as.character(b1$Repeat)
  #print(rep)
  y1=((2*j)-0.5)-2
  y2=((2*j)+0.5)-2
  if(rep == "GHP"){
    rect(x1,y1,x2,y2, brder="transparent", col=c("red"))}
  if(rep == "HP"){
    rect(x1,y1,x2,y2, brder="transparent", col=c("blue"))}
  rplabel=paste(b1$Repeat,' (',b1$rpt_ln,') ',sep='')
  text((x1+x2)/2,y2+0.3,labels=rplabel)
}

legend("bottomright", legend = c(rpt$residue), col = c(rpt$color) , horiz = T, fill = rpt$color, inset = c(0.042,-0.01), bty="n", cex=2)
title = ('Repeat length distribution of'~italic(HRG)~'gene across different species in all clade')
mtext(title ,side=3,cex=2,adj=0.5,outer=T,line=-4)
dev.off()
