getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/5a")

library(phytools)

t = read.tree("primates.nwk")
data = read.csv(file = "5a_table.csv", header = F)
data$V4 = data$V2 /(data$V2 + data$V3)
data$V5 = paste("(", data$V2, ",", data$V3, ")", sep="")

jpeg("5a_pie.jpeg", width=20, height=20, units="in", res=300)
plot.phylo(t, use.edge.length=F, node.depth=2, label.offset=2, x.lim=30, cex=1.5, edge.width=2, main="Frequency of expanded and contracted genes in primates clade")
tiplabels(pie = data$V4, piecol = c("gold","purple"), cex=0.6)
tiplabels(data$V5, offset=1.2, cex=1.5, frame="none")
legend(x=20, y=5, legend = c("Genes with expanded repeats", "Genes with contracted repeats"), col=c("gold" , "purple"), pch = 15, pt.cex = 3, cex = 1.5,  horiz = F, box.lwd = 0, box.col = "white", bg = "white")
dev.off()
