getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/5b")

library(stringr)
library(gplots)

data <- read.csv("5b_table.csv", header=T)
rownames(data) <- data[,1]
mtx <- as.matrix(data[,-1])
jpeg("5b_heatmap.jpeg",width=15,height=12,units="in",res=500)
par(oma=c(0,0,2,1))
heatmap.2(mtx, Colv = F, Rowv = F, na.rm=T, col = greenred(300), trace = "none", density.info = "none", scale="none")
dev.off()
