setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Immune_genes_repeats-main/Immune_genes_repeats-main/immune_scripts/immune_scripts/main_results_scripts/figure_3/3a")
getwd()
setwd = ("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/3a")

library(stringr)
data = read.csv("3a.csv",header = T)
data$Rpt_len = (data$End_u - data$Start_u ) + 1
amino = as.data.frame(strsplit(paste(data$Repeat,collapse=""),split=""))
aas=data.frame(unique(amino)[,1])
colnames(aas)=c("residue")
Residue <- aas[order(aas$residue), ]
aas$residue <- Residue
aas$code = (col = c("deeppink","violet","purple","blue","cyan","green","darkgreen","yellow","orange","red","maroon","brown","black"))
Organism <- as.data.frame(unique(data$Organism))
colnames(Organism)="Organism_name"
n = length(Organism$Organism_name)
jpeg(paste('Repeatplot_for_figure3a.jpeg',sep=''),width=38,height=14,units="in",res=300)
par(mai=c(1,0.5,0,0),oma=c(0.5,0.2,0,0.2),xpd=T)
###Plotting the rectangular boxes on the right side of the plot
plot(1, type="n", xlab="", ylab="", xlim=c(0, 136), ylim=c(0, 2*n),axes=F)
for(j in seq(0,(n-1))){
  y1=(2*j) - 0.6
  y2=(2*j) + 0.6
  rect(20,y1,120,y2)}
###Printing Organism names
for(j in seq(0,(n-1))){
  x1=10
  y1=(2*j)+0.5
  legend(x1,y1,legend=gsub("_"," ",as.character(Organism[j+1,1])),text.font=3,cex=1.5,adj=c(1,0), bty = "n")}
###printing the gene name on the right side
gene=as.character(unique(data$Gene))
for(j in seq(0,(n-1))){
  x1=130
  y1=(2*j)+0.5
  legend(x1,y1,legend=as.character(gene[j+1]),text.font=2,cex=1.5,bty="n")}

###Plotting the repeats at their specific coordinates
for(z in 1:dim(data)[1]){
  b1=data[z,]
  org_name=b1[1,"Organism"]
  ###get the number at which the Organism is written
  j=which(Organism$Organism_name==org_name)
  x1=20 + (b1$Start_a/b1$Length_a)*100
  x2=20 + ((b1$Start_a + b1$Rpt_len)/b1$Length_a)*100
  s=as.character(b1$Repeat)
  print(s)
  y1=((2*j)-0.5)-2
  y2=((2*j)+0.5)-2
  if(nchar(s)>4){
    for(i in 1:nchar(s)){
      if(i<=nchar(s)-1){
        aanow=data.frame(strsplit(s,split=""))[i,]
        meracol=aas[aas$residue==aanow,2]
        rect(x1,y1,x2,y2,brder="transparent",col=meracol,lty="dashed",density=30,angle=45*i)}
      else {aanow=data.frame(strsplit(s,split=""))[5,]
      meracol=aas[aas$residue==aanow,2]
      rect(x1,y1,x2,y2,border=meracol,lwd=3)
      }
    }
  } else {for(i in 1:nchar(s)){
    aanow=data.frame(strsplit(s,split=""))[i,]
    meracol=aas[aas$residue==aanow,2]
    rect(x1,y1,x2,y2,border="transparent",col=meracol,lty="dashed",density=30,angle=45*i)
  }
  }
  rplabel=paste(b1$Repeat,' (',b1$Rpt_len,') ',sep='')
  text((x1+x2)/2,y2+0.3,labels=rplabel,cex=1.1)
}
ld=data.frame(unique(as.data.frame(strsplit(paste(data$Repeat,collapse=""),split="")))[,1])
colnames(ld)=c("residue")
ld$residue = Residue
aminocol<-merge(ld,aas,by="residue")
legend("bottomright",legend=aminocol$residue,col=aminocol$code,horiz=T,fill=aminocol$code,inset=c(0.042,-0.06),bty="n",cex=2)
mtext('Occurrence of multiple repeats in immune genes across different Organism in different clade',side=3,cex=2,adj=0.5,outer=T,line=-2)
dev.off()
