getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/2a")

dat = read.csv(file = "2a_table.csv", header = TRUE)
dat
head(dat)

E = dat$end_unaln
S = dat$start_unaln
CDS = dat$unaln_cds_length
L = (E-S)
SP = (S/CDS)
EP = (E/CDS)

dat$repeat_length_unaln <- L
dat$start_position <- SP
dat$end_position <- EP

library(ggplot2)
jpeg("2a_heatmap.jpeg",width=28,height=18,units="in",res=300)
ggplot(dat, aes(y=gc_percent,x=end_position)) + geom_bin2d(bins = 9) + scale_fill_continuous(type = "gradient") + theme_bw() + xlab("Relative position along the gene") + ylab("GC percent")+ theme(axis.text = element_text(size = 20)) + theme(axis.title = element_text(size = 20))
dev.off()

