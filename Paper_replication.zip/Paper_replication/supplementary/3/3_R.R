getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/supplementary/3")

library(phytools)

t1 = read.tree("amphibia.nwk")
data = read.csv("3_table.csv", header = T)
data$percent = data$Expand / (data$Expand + data$Contract)

df = data.frame()
for(org in t1$tip.label){
  df = rbind(df, data[data$Organism == org,])}
df$coord = paste("(",df$Expand,",",df$Contract,")",sep="")

jpeg("3_pie.jpeg",width=20,height=20,units="in",res=300)
plot.phylo(t1, use.edge.length = F, node.depth = 1.5, label.offset = 2, x.lim = 30, cex = 2, edge.width = 2, main = "Frequency of expanded and contracted genes in amphibia clade")
tiplabels(pie = df$percent, piecol = c("purple","gold"), cex = 0.6)
tiplabels(df$coord, offset = 1.2, cex = 1.5, frame = "none")
legend(x = 23, y = 3, legend = c("Genes with expanded repeats", "Genes with contracted repeats"), col = c("purple","gold"), pch = 15, pt.cex = 3, cex = 1.5,  horiz = F,box.lwd = 0,box.col = "white",bg = "white")
dev.off()