getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/supplementary/2a")

data = read.table("2a_table", header = F)
histogram = hist(data$V1, plot = F, breaks = 0:max(data$V1))

jpeg("2a_line.jpeg",width=14,height=9,units="in",res=300)
plot(histogram$breaks[-1], histogram$density, type = "o", ylab = "Percentage", xlab = "Number of repeats", main = "Distribution of number of repeats in immune genes", lwd = 2, col = "blue", cex.lab = 1.25, cex.main = 2)
text(max(histogram$breaks)-1, max(histogram$density)-5, labels = paste('Total sequences: ', (dim(data)[1])))
dev.off()
