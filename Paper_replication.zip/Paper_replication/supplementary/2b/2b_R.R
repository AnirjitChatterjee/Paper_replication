getwd()
setwd("C:/Users/ANIRJIT CHATTERJEE/Desktop/Paper_replication/supplementary/2b")

data = read.table("2b_table")
data$prop[data$V4 == "G" | data$V4 == "A" | data$V4 == "V" | data$V4 == "L" | data$V4 == "I" | data$V4 == "M" ] = "non_polar_aliphatic"
data$prop[data$V4 == "F" | data$V4 == "Y" | data$V4 == "W"] = "non_polar_aromatic"
data$prop[data$V4 == "P" | data$V4 == "S" | data$V4 == "T" | data$V4 == "C" | data$V4 == "N" | data$V4 == "Q" ] = "polar_uncharged"
data$prop[data$V4 == "D" | data$V4 == "E" ] = "negatively_charged"
data$prop[data$V4 == "R" | data$V4 == "H" | data$V4 == "K" ] = "positively_charged"

histogram = hist(data[data$prop == "non_polar_aromatic",]$V6, plot = F, breaks = seq(from=0,to=100,by=10))
histogram$freq = histogram$counts / sum(histogram$counts)
df = data.frame(histogram$breaks[-1],histogram$freq)
colnames(df) = c("intervals", "non_polar_aromatic")

histogram = hist(data[data$prop == "non_polar_aliphatic",]$V6, plot = F, breaks = seq(from=0,to=100,by=10))
histogram$freq = histogram$counts / sum(histogram$counts)
df2 = data.frame(histogram$breaks[-1],histogram$freq)
colnames(df2) = c("intervals", "non_polar_aliphatic")
final_df = merge(df, df2, by = "intervals")

histogram = hist(data[data$prop == "polar_uncharged",]$V6, plot = F, breaks = seq(from=0,to=100,by=10))
histogram$freq = histogram$counts / sum(histogram$counts)
df3 = data.frame(histogram$breaks[-1],histogram$freq)
colnames(df3) = c("intervals", "polar_uncharged")
final_df = merge(final_df, df3, by = "intervals")

histogram = hist(data[data$prop == "negatively_charged",]$V6, plot = F, breaks = seq(from=0,to=100,by=10))
histogram$freq = histogram$counts / sum(histogram$counts)
df4 = data.frame(histogram$breaks[-1],histogram$freq)
colnames(df4) = c("intervals", "negatively_charged")
final_df = merge(final_df, df4, by = "intervals")

histogram = hist(data[data$prop == "positively_charged",]$V6, plot = F, breaks = seq(from=0,to=100,by=10))
histogram$freq = histogram$counts / sum(histogram$counts)
df5 = data.frame(histogram$breaks[-1],histogram$freq)
colnames(df5) = c("intervals", "positively_charged")
final_df = merge(final_df, df5, by = "intervals")

write.table(final_df, file = 'rel_pos_aa.txt', quote = F, col.names = T, row.names = F, sep = "\t")

jpeg("2b_histogram.jpeg",width=14,height=9,units="in",res=300)
plot(2, xlim = c(0,100), ylim = c(0,1), xlab = "", ylab = "", xaxt = "n", main = "Frequency of repeats along the gene", cex.axis = 1.5, cex.main = 1.5)
axis(1, at = seq(from = 5, to = 95, by = 10), labels = c("0-10", "10-20", "20-30", "30-40", "40-50", "50-60", "60-70", "70-80", "80-90", "90-100"), tick = F)
color = c("red","yellow","cyan","lightgreen","pink")
for(r in 1:dim(final_df)[1]){
  r1 = final_df[r,]
  x1 = r1[1,1]-10
  for(c in 2:dim(r1)[2]){
    x2 = x1+2
    rect(x1,0,x2,r1[1,c], col = color[c-1])
    x1=x1+2}
}

title(ylab = "Proportion", line = 2.5, cex.lab = 1.5)        
title(xlab = "Relative positive in a gene", line = 3, cex.lab = 1.5)

npr = dim(a[data$prop=="non_polar_aromatic",])[1]
npl = dim(a[data$prop=="non_polar_aliphatic",])[1]
pu = dim(a[data$prop=="polar_uncharged",])[1]
nc = dim(a[data$prop=="negatively_charged",])[1]
pc = dim(a[data$prop=="positively_charged",])[1]

legend(55, 0.95, box.col = "white", bg = "white", box.lwd = 0, legend = c((paste("Nonpolar aromatic (", npr, ")")), (paste("Nonpolar aliphatic (", npl, ")")), (paste("Polar uncharged (", pu, ")")), (paste("Negatively charged (", nc, ")")), (paste("Positively charged (", pc, ")"))),fill = color, cex = 2)
dev.off()
